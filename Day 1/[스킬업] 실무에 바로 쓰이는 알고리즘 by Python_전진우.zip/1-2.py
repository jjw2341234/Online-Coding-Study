n = int(input("숫자를 입력하세요: "))
if n%2:
    print("홀수입니다.")
else:
    print("짝수입니다.")